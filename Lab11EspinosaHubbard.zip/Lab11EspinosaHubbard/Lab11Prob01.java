import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * File: Lab11Prob01.java
 * Class: CSCI 1302
 * Author: Lab11EspinosaHubbard
 * Created on: Apr 25, 2025
 * Last Modified: Apr 25, 2025
 * Description: Keeps same functionality in program without usage of break or continue
 */
public class Lab11Prob01 {

	public static void main(String[] args) {
		
		
		File fileInput = new File("src/people.dat");
		File fileOutput = new File("src/people-copy.dat");
		
		try (
				DataInputStream input = new DataInputStream(new FileInputStream(fileInput));
				DataOutputStream output = new DataOutputStream(new FileOutputStream(fileOutput));
			) {
			
			while (true) {
				int age = input.readInt();
				String fullName = input.readUTF();
				String address = input.readUTF();
				int zipCode = input.readInt();
				double salary = input.readDouble();
				
				System.out.printf("%d %s %s %d% .2f%n",age,fullName,address,zipCode,salary);
				output.writeInt(age);
				output.writeUTF(fullName);
				output.writeUTF(address);
				output.writeInt(zipCode);
				output.writeDouble(salary);
			} 
			
		} catch (EOFException ex) {
			
		} catch(IOException ex) {
			
		}
	}

}
